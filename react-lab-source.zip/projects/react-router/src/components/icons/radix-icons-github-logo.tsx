import * as React from "react";

export function GithubLogoIcon({
  size = 15,
  color = "currentColor",
  strokeWidth = 2,
  className,
  ...props
}: React.SVGProps<SVGSVGElement> & {
  size?: number;
  color?: string;
  strokeWidth?: number;
}) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 15 15"
      fill="none"
      stroke={color}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      {...props}
    >
      <path d="M7.499.25a7.25 7.25 0 0 1 2.297 14.129c-.367.07-.498-.155-.498-.349c0-.237.009-1.02.009-1.989c0-.676-.233-1.119-.493-1.343c1.615-.18 3.311-.792 3.311-3.577c0-.792-.28-1.438-.745-1.945c.074-.184.322-.92-.073-1.92c-.015-.004-.625-.182-1.992.744A7 7 0 0 0 7.5 3.756A7 7 0 0 0 5.686 4C4.3 3.062 3.69 3.257 3.69 3.257c-.394.998-.146 1.735-.07 1.919a2.8 2.8 0 0 0-.747 1.945c0 2.778 1.693 3.4 3.303 3.583c-.207.181-.394.5-.46.969c-.413.185-1.464.506-2.11-.602c0 0-.383-.695-1.11-.747c0 0-.709-.009-.05.44c.014.008.48.237.804 1.061c.005.016.437 1.407 2.442.972c.004.605.01 1.061.01 1.233c0 .193-.132.416-.495.35A7.25 7.25 0 0 1 7.499.25"/>
    </svg>
  );
}
